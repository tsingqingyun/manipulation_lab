# Manipulation Learning Lab — Group Report

Status: DRAFT — complete Q1–Q5 and mark the first observable error before submission

Run: `20261013T051828Z_5a8ae81c`. Policy: **student_deterministic_mlp** (student).
Training: 50 epochs, selected epoch 12, validation action MSE 0.03538; 9.6s.

| Condition | Episodes | Environment success | Stable released placement |
|---|---:|---:|---:|
| standard | 5 | 60% | 60% |
| shifted | 5 | 60% | 60% |

Five episodes give a coarse classroom estimate. Position Shift Test is not a certified OOD benchmark.

## Demonstration understanding

Q1: [Complete this answer]

Demonstration reflection: [Complete this answer]

## Training and evaluation discussion

Q2 — How BC learns: [Complete this answer]

Q3 — Loss versus performance: [Complete this answer]

Q4 — Initial position: [Complete this answer]

Q5 is addressed by the failure analysis below.

## Failure analysis

Episode: standard_00; evidence policy role: student.

**Failure stage:** [Complete this answer]

**First observable error — fact:** [Complete this answer]

**Possible cause — hypothesis:** [Complete this answer]

**Proposed improvement:** [Complete this answer]

**First error control step (student annotation):** None

![Training curve](../experiment_051841_40b7a2/lr_a/training/training_curve.png)

![Failure signals](../analysis_052223_a4eb37/failure_signals.png)

## Evidence and limits

Checkpoint SHA256: `e9771831a6563677cd6db4585b630b54c6f1e14668e4443e1a71e705290c7033`.
Positions are simulator world coordinates in meters; logs use 20Hz control steps. No real-robot claim is made.
Attach training_config.json, training_log.csv, evaluation results/config/manifest, and 3 keyframes. Keep raw artifacts separately.

Requested control step 0; recorded step 1 (offset +1); video frame 0.
![Selected keyframe](../analysis_052223_a4eb37/keyframe_0.png)

Requested control step 250; recorded step 249 (offset -1); video frame 62.
![Selected keyframe](../analysis_052223_a4eb37/keyframe_1.png)

Requested control step 500; recorded step 497 (offset -3); video frame 124.
![Selected keyframe](../analysis_052223_a4eb37/keyframe_2.png)

## Mandatory learning-rate controlled experiment

Data, initialization, seed, architecture, epochs and evaluation cases are fixed. Both variants are retained; test results do not select the primary model.

| Variant | Learning rate | Validation MSE | Standard stable | Shifted stable |
|---|---:|---:|---:|---:|
| lr_a | 0.001 | 0.035376 | 60% | 60% |
| lr_b | 0.0003 | 0.034123 | 100% | 100% |

![Both training curves](../experiment_051841_40b7a2/learning_rate_curves.png)

![Initial positions](../experiment_051841_40b7a2/lr_a/evaluation/initial_positions.png)
