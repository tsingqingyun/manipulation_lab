# Manipulation Learning Lab — Group Report

Status: student answers provided; instructor review required

Run: `20261013T051828Z_5a8ae81c`. Policy: **student_deterministic_mlp** (student).
Training: 50 epochs, selected epoch 12, validation action MSE 0.03538; 9.6s.

| Condition | Episodes | Environment success | Stable released placement |
|---|---:|---:|---:|
| standard | 5 | 60% | 60% |
| shifted | 5 | 60% | 60% |

Five episodes give a coarse classroom estimate. Position Shift Test is not a certified OOD benchmark.

## Demonstration understanding

Q1: The policy observes 16 values: end-effector world position (3), end-effector xyzw quaternion (4), two finger joint positions (2), and can world position plus xyzw quaternion (7). Positions and finger joint displacements are in meters, with world Z upward; quaternion components are dimensionless. The adapter takes object[7:14] from the raw 14-value object vector in both training and inference. The seven normalized actions are world translation increments (3), axis-angle rotation increments (3), and one gripper command (1). Commands lie in [-1,1]; translation and rotation scale to controller limits of +/-0.05 m and +/-0.5 rad. A positive gripper command closes and a negative command opens; it is not a measured opening in meters. Two finger joints give two observation values but only one independent open/close command. The control frequency is 20 Hz, so one interval is 0.05 s; step indices are not acquisition timestamps.

Demonstration reflection: demo_0 contains 118 recorded steps. Its first positive gripper command is action index 52; the can height ranges from 0.85851 to 1.01071 m over the recorded observations. A final image cannot reveal approach, closure, lift, transport and release ordering or provide the aligned observation/expert-action pairs needed for training. The trajectory does. A commanded closure alone does not prove secure grasping. Demonstration playback restores recorded simulator states and is distinct from a learned-policy rollout. The 160/20/20 split keeps complete episodes together, reducing leakage of adjacent correlated states; only the 160 training episodes supply normalization statistics.

## Training and evaluation discussion

Q2 — How BC learns: Behavior cloning is supervised learning of a policy pi_theta(o) that maps the current 16-value observation to the seven recorded expert action labels. The fixed deterministic MLP has three 256-unit hidden layers. It minimizes mean squared action error, averaged over examples and action coordinates; gradient-based updates change the network weights. An epoch traverses the training examples. Observation normalization uses training data only. Validation loss is measured without fitting validation labels and selects the saved checkpoint; both variants selected epoch 12 out of 50. The test episodes never update weights or select the primary model. The mandatory experiment changes only learning rate (0.001 vs 0.0003), keeping seed 17, batch size 256, data, episode split, initialization, network, normalization, training device and evaluation cases fixed. All four control checks passed. lr_a was declared primary before testing.

Q3 — Loss versus performance: No. In this actual CPU run, epoch-50 training MSE is 0.01771696 for lr_a and 0.02091872 for lr_b, so lr_a fits training examples more closely. Their best validation MSE values are 0.03537583 and 0.03412256, both at epoch 12. Using those validation-selected checkpoints, lr_a achieves stable released placement in 3/5 standard and 3/5 shifted cases, while lr_b achieves 5/5 and 5/5. Environment-success counts happen to match stable-placement counts here, but the definitions differ. The evaluated weights are epoch-12 checkpoints, not the epoch-50 weights: this comparison warns against ranking policies by final training loss; it is not a causal test of loss at fixed weights. During closed-loop execution, each action changes subsequent observations, so errors can move the policy into states less well represented in demonstrations. Five cases per condition are coarse (one case equals 20 percentage points), and this one training seed cannot establish a generally superior learning rate. No unsuccessful cases were discarded or rerun to improve scores.

Q4 — Initial position: The shift adds +0.04 m to the initial can world X while retaining the same held-out source episode and seed, with the shifted position constrained to the source bin. All paired success/failure labels are unchanged in this run: lr_a succeeds on demo_185, demo_29 and demo_157 and fails on demo_39 and demo_48 under both conditions; lr_b succeeds on all five under both. However, behavior is not identical. For lr_a on demo_185, seed 102, stable completion takes 141 standard steps versus 156 shifted steps, a 15-step (0.75 s) increase. For lr_b on demo_48, completion instead changes from 182 to 141 steps. A possible explanation is different approach/grasp geometry, but the timing difference alone cannot prove that mechanism. In the coverage plot, grey dots are 160 training initial positions, colored markers are actual evaluated starts, and lines connect paired starts: none is a trajectory or a success marker. Shifted starts can overlap the training-position range, and world XY alone omits the other observation dimensions. Thus this is a position sensitivity test, not certified out-of-distribution generalization.

Q5 is addressed by the failure analysis below.

## Failure analysis

Episode: standard_00; evidence policy role: student.

**Failure stage:** grasp retention / beginning of lift

**First observable error — fact:** In primary student lr_a, standard_00 (demo_39, seed 101), contact is true at states 49-56 and becomes false at state 57, remaining false to the end. I annotate state 57 as the first directly supported loss of grasp contact, not as a proven earliest causal deviation. At state 57 (2.85 s of control time), opening is 0.022398 m, end-effector Z is 0.883759 m, can Z is 0.864667 m, and preceding action a[56] commands closure approximately +1. At state 65, end-effector Z rises to 0.962711 m but can Z returns to 0.860271 m and opening shrinks to 0.002242 m: the hand rises without retaining the can. The maximum object lift over the rollout is only 0.005722 m; no target-margin or environment success occurs before the 500-step horizon. Inspected states 45, 53, 57 and 65 correspond exactly to recorded video frames 11, 13, 14 and 16, with zero offset. In general a[t-1] leads to s[t], and video samples states 1,5,9,... after actions, so nearby frames must not be treated as exact requested states.

**Possible cause — hypothesis:** The approach pose may not center the can securely between the fingers, or closure and upward motion may be poorly timed. A positive closure command and brief contact do not guarantee force closure or persistent retention. Logged contact loss and the video support failed retention, but do not distinguish alignment, timing and contact dynamics. The single-view video does not identify the earliest causal error or prove covariate shift; those remain hypotheses.

**Proposed improvement:** Proposed, not executed: capture the complete simulator and controller state just before closure, including the same policy checkpoint and random state. Compare an unchanged continuation with one predefined intervention that holds the pre-lift end-effector pose while closing for a fixed five control steps, then resumes the same policy. Change only that timing rule, keep the initial state, dynamics and success thresholds identical, and compare duration of contact, can height relative to its initial height, and eventual stable placement on the same cases. An improvement would support a closure-timing contribution; no improvement would leave alignment/contact hypotheses unresolved. This tests an intervention, not a claimed guaranteed fix. Any additional data or model modification should be a separate declared experiment.

**First error control step (student annotation):** 57

![Training curve](../experiment_051841_40b7a2/lr_a/training/training_curve.png)

![Failure signals](../analysis_052630_4b175c/failure_signals.png)

## Evidence and limits

Checkpoint SHA256: `e9771831a6563677cd6db4585b630b54c6f1e14668e4443e1a71e705290c7033`.
Positions are simulator world coordinates in meters; logs use 20Hz control steps. No real-robot claim is made.
Attach training_config.json, training_log.csv, evaluation results/config/manifest, and 3 keyframes. Keep raw artifacts separately.

Requested control step 45; recorded step 45 (offset +0); video frame 11.
![Selected keyframe](../analysis_052630_4b175c/keyframe_0.png)

Requested control step 53; recorded step 53 (offset +0); video frame 13.
![Selected keyframe](../analysis_052630_4b175c/keyframe_1.png)

Requested control step 57; recorded step 57 (offset +0); video frame 14.
![Selected keyframe](../analysis_052630_4b175c/keyframe_2.png)

Requested control step 65; recorded step 65 (offset +0); video frame 16.
![Selected keyframe](../analysis_052630_4b175c/keyframe_3.png)

## Mandatory learning-rate controlled experiment

Data, initialization, seed, architecture, epochs and evaluation cases are fixed. Both variants are retained; test results do not select the primary model.

| Variant | Learning rate | Validation MSE | Standard stable | Shifted stable |
|---|---:|---:|---:|---:|
| lr_a | 0.001 | 0.035376 | 60% | 60% |
| lr_b | 0.0003 | 0.034123 | 100% | 100% |

![Both training curves](../experiment_051841_40b7a2/learning_rate_curves.png)

![Initial positions](../experiment_051841_40b7a2/lr_a/evaluation/initial_positions.png)
